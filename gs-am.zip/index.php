<?php
/**
 * Index
 *
 * @package gabischiopu
 */

declare( strict_types=1 );
/**
 * Silence is golden.
 */
